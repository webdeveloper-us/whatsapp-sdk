---
id: SimpleTextObject
title: SimpleTextObject
---

# Text Object
The general object containing a text string.

## Example
```json
{
    "text": "MESSAGE_CONTENT",
}
```

## Properties
1. `text` : string — a text string to be displayed.
