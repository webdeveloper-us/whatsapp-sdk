---
id: PhoneNumbersResponseObject
title: PhoneNumbersResponseObject
---

# Phone Numbers Response Object
The successful response body JSON from the Cloud API for requesting verification and/or verifying a phone number.

### Example
```json
{
  "success": true
}
```

## Properties
1. `success` : boolean — the state of a successful request.
